miFuncion(4, 2);

//Declaración de la función
function miFuncion(a, b){
    console.log("Suma: " + (a + b));   
}

//Llamando a la función
miFuncion(2, 3);

