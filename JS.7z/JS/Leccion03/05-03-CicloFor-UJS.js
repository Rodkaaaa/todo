/*
let contador = 0;
while( contador < 3 ){
    console.log(contador);
    contador++;
}

do{
    console.log(contador);
    contador++;
}while(contador < 3);
*/

for(let contador = 0; contador < 3 ; contador++ ){
    console.log(contador);
}
console.log("Fin ciclo for");