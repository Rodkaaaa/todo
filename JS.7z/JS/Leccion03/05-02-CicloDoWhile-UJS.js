let contador = 0;
/*
while( contador < 3 ){
    console.log(contador);
    contador++;
}
*/

do{
    console.log(contador);
    contador++;
}while(contador < 3);
console.log("Fin ciclo do while");