let condicion = false;

if(condicion){
    console.log("Condición verdadera");
    console.log("fin del programa");
}
else{
    console.log("Condición falsa");
}