"use strict";

let x = 10;
console.log(x);

miFuncion();

function miFuncion(){
    "use strict"
    let y = 15;
    console.log(y);
}