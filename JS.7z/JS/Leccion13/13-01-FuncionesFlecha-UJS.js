let miFuncion = function (){
    console.log('saludos desde mi función');
}

const miFuncionFlecha = () => {
    console.log('saludos desde mi función flecha');
}

miFuncionFlecha();

miFuncion();


