function EsPar(a) {

    if (a % 2 ==0) {
    console.log("Es un numero par")
    }else{
    console.log("No es par")
    }
}
EsPar(7);