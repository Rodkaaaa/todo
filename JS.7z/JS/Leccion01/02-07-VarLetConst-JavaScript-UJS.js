let nombre;
nombre = "Juan";
console.log( nombre );

const apellido = "Perez";
apellido = "Lara"; //Error no se puede cambiar el valor de una constante