let a = 1;

a += 3; // a = a + 3
console.log(a);

a -= 2; // a = a - 2
console.log(a);

a **= a
console.log(a)
/*
*=
/=
%=
**=
*/
