var nombre = "Hola mundo";

console.log(nombre);


