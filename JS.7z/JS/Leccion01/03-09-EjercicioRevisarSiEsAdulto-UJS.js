let edad = 18, adulto = 18;

if( edad >= adulto ){
    console.log( "Es un adulto" );
}
else{
    console.log( "Es menor de edad" );
}
