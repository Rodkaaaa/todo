let resultado = (1>2) ? "verdadero" : "falso";
console.log(resultado);

let numero = 150;
resultado = ( numero % 2 == 0 ) ? "Número par" : "Número impar"; 
console.log( resultado );