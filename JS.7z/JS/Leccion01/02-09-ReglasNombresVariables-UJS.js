let nombreCompleto = "Juan Perez";
let nombrecompleto = "Carlos Lara";
console.log( nombreCompleto );
console.log( nombrecompleto );

let a1nombreCompleto;
let _nombreCompleto;
let $nombreCompleto;
//let 1nombreCompleto; no está permitido iniciar el nombre de una variable con numeros

let ruptura = 10;